# Spotify Twitch Extension panel

Statický Twitch Extension panel, který přijímá aktuálně přehrávanou skladbu
přes Twitch Extension PubSub a zobrazí její název, interprety a obal alba.
Nepotřebuje build ani Spotify přihlašovací údaje v prohlížeči.

## Jak data putují

1. Next.js server každých 10 sekund načte Spotify přehrávání pomocí uloženého
   Spotify připojení.
2. Když se přehrávání změní, backend podepíše krátkodobý Extension JWT a zavolá Twitch Helix
   `extensions/pubsub` pro nastavený broadcaster kanál. Spotify token ani
   Extension secret se do panelu nikdy neposílají.
3. Panel poslouchá `Twitch.ext.listen("broadcast", ...)`, zpracuje JSON a
   zobrazí skladbu. Pokud Spotify nic nepřehrává nebo vrátí prázdný výsledek,
   zobrazí stav „právě nic nepřehrává“.

Publikovaná zpráva má tento tvar:

```json
{
  "type": "spotify",
  "updatedAt": "2026-10-10T12:00:00.000Z",
  "data": {
    "is_playing": true,
    "item": {
      "name": "Název skladby",
      "artists": [{ "name": "Interpret" }],
      "external_urls": {
        "spotify": "https://open.spotify.com/track/..."
      },
      "album": {
        "images": [{ "url": "https://i.scdn.co/image/..." }]
      }
    }
  }
}
```

`data` může být také `null`, případně může obsahovat `is_playing: false` nebo
`item: null`. Panel tyto stavy zpracuje bez chyby.

## Nahrání panelu

1. Nahrajte `panel.html`, `panel.css` a `panel.js` na HTTPS statický hosting.
   Zachovejte jejich názvy a umístěte je vedle sebe; není potřeba nic
   kompilovat. URL musí být veřejně dostupná přes HTTPS.
2. V Twitch Developer Console nastavte URL souboru `panel.html` jako URL
   panelu své Extension a nakonfigurujte Extension pro stejný broadcaster
   kanál, který používá backend.
3. Pokud se nezobrazuje obal alba, povolte v Content Security Policy Extension
   obrázky z `i.scdn.co`.
4. V backendu nastavte `TWITCH_EXTENSION_ID`,
   `TWITCH_EXTENSION_SECRET_BASE64` (Base64 Extension secret),
   `TWITCH_EXTENSION_BROADCASTER_ID` (číselné Twitch ID vysílatele) a
   `STREAMERBOT_INGEST_TOKEN`. Pro získání přehrávání musí být také nastavené
   Spotify OAuth proměnné a Spotify účet musí být připojený.
5. Streamer.bot není pro Spotify PubSub potřeba. Po spuštění Next.js serveru
   server automaticky kontroluje Spotify a při změně publikuje data do Twitch.
   Pokud chybí konfigurace Twitch Extension, server vypíše chybu do logu.

Panel poslouchá broadcasty pro broadcaster kanál, takže Twitch Extension musí
být otevřená na stejném kanálu, pro který backend zprávy publikuje.
